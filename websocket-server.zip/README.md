# TUGAS BESAR 2 JARINGAN KOMPUTER
## SIMPLE WEBSOCKET SERVER

## K-02 / Kelompok 10 (Kimi no Network)

### Petunjuk Program

#### Penerimaan file baru
Unzip file zip yang diterima, lalu jalankan websocket.py

#### Perintah yang dapat digunakan
!echo       : Server akan merespon dengan message setelah !echo
!submission : Server akan mengirim file binary berisi source code + README.md dalam zip
kirim file  : Server akan mengecek md5 antara file yang diberikan dan zip. Jika sama, maka respon = 1, jika tidak, respon = 0

### Pembagian Tugas
NIM         Nama                    Pembagian Kerja             Kontribusi
13517023    Kevin Sendjaja          md5 checking                33% 
13517050    Christopher Billy S.    echo, message handling      33% 
13517131    Jan Meyer Saragih       handshake, file sending     33%